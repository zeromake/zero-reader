#!/bin/bash
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)

export LD_LIBRARY_PATH=${SHELL_FOLDER}/lib/
${SHELL_FOLDER}/pdf2htmlEX $@